﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trizetto.DotNetExtensions.Diagnostics;
using Trizetto.EdiServiceAdapter.Api;
using Trizetto.EdiServiceAdapter.Api.Models;
//using Trizetto.SubscriberLookup.Core;
using Trizetto.X12Parser.Models;

namespace Trizetto._270_271_PreProcessor
{
    [Preprocessor(nameof(_270_271_preprocessor), "005010X279A1")]
    public class _270_271_preprocessor : IPreprocessor
    {
        public Task<bool> PreprocessRequestAsync(IEdiContext context, X12TransactionSet requestTs)
        {
            return Task.FromResult(true);
        }
    }
}
